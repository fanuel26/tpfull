

<?php $__env->startSection('content'); ?>
<section class="container">
    <div class="row top">
        <div class="col-md-8 offset-md-2 my-5">
            <h1 class="h11 text-center title text-primary" data-aos="fade-up">
                Inscrivez vous dès maintenant !
            </h1>
        </div>
        <div class="col-md-8 offset-md-2">
            <?php if($errors->any()): ?>
            <div style="color: red;">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(url('save_service')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group my-3">
                            <label>Civilité</label>
                            <select type="text" class="form-control form-control-lg" name="civilité">
                                <option value="Monsieur">Monsieur</option>
                                <option value="Madame">Madame</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6"></div>
                    <div class="col-md-6 my-3">
                        <div class="form-group">
                            <label>Nom & Prénoms</label>
                            <input type="text" name="nom" value="<?php echo e(old('nom')); ?>" class="form-control form-control-lg"
                                placeholder="Votre nom et prénom">
                                <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 my-3">
                        <div class="form-group">
                            <label>Date de naissance</label>
                            <input type="date" name="date" value="<?php echo e(old('date')); ?>"
                                class="form-control form-control-lg">
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 my-3">
                        <div class="form-group">
                            <label>N° de téléphone</label>
                            <input type="tel" name="telephone" value="<?php echo e(old('telephone')); ?>"
                                class="form-control form-control-lg" placeholder="Numero de téléphone">
                                <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 my-3">
                        <div class="form-group">
                            <label>Adresse email</label>
                            <input type="text" name="email" value="<?php echo e(old('email')); ?>"
                                class="form-control form-control-lg" placeholder="Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 my-3">
                        <div class="form-group">
                            <label>Secteur d'activité</label>
                            <input type="text" name="secteur_activite" value="<?php echo e(old('secteur_activite')); ?>"
                                class="form-control form-control-lg" placeholder="Votre secteur">
                                
                            <?php $__errorArgs = ['secteur_activite'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 my-3">
                        <div class="form-group">
                            <label>Code postal</label>
                            <input type="text" name="code_postal" value="<?php echo e(old('code_postal')); ?>"
                                class="form-control form-control-lg" placeholder="Votre code postal">
                                
                            <?php $__errorArgs = ['code_postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 my-3">
                        <div class="form-group">
                            <label>Ville</label>
                            <input type="text" name="ville" value="<?php echo e(old('ville')); ?>"
                                class="form-control form-control-lg" placeholder="Votre ville">
                                
                            <?php $__errorArgs = ['ville'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6 my-3">
                        <div class="form-group">
                            <label>Pays</label>
                            <input type="text" name="pays" value="<?php echo e(old('pays')); ?>"
                                class="form-control form-control-lg" placeholder="Votre pays">
                                
                            <?php $__errorArgs = ['pays'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-12 my-3">
                        <div class="form-group">
                            <label class="">Commentaire</label>
                            <textarea type="text" name="commentaire" value="<?php echo e(old('commentaire')); ?>"
                                class="form-control form-control-lg" rows="5"
                                placeholder="Votre commentaire"></textarea>
                                
                            <?php $__errorArgs = ['commentaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-12 my-3">
                        <div class="form-check">
                            <label for="certifie_majeur">
                                <input type="checkbox" id="certifie_majeur" name="certifie_majeur" <?php echo e(old('certifie_majeur') ? 'checked' : ''); ?>>
                                Je certifie être majeur.
                            </label>
                            <?php $__errorArgs = ['certifie_majeur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-12 my-3 text-right">
                        <button class="btn btn-primary btn-lg" type="submit">Envoyer</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.base1", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MAONO\Documents\github\tpfull\resources\views/home/detail.blade.php ENDPATH**/ ?>